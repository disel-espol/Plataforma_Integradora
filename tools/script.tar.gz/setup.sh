#!/bin/bash
sudo mkdir -p /mnt/extra/setup
cd /mnt/extra/setup || exit 1
sudo wget https://github.com/datacharmer/dbdeployer/releases/download/v1.58.0/dbdeployer-1.58.0.linux.tar.gz 
sudo tar -xzf dbdeployer-1.58.0.linux.tar.gz 
sudo chmod +x dbdeployer-1.58.0.linux 
sudo mv dbdeployer-1.58.0.linux /usr/local/bin/dbdeployer 
sudo dbdeployer 
sudo apt-get update 
sudo apt-get install libaio1 
sudo dbdeployer init  
sudo wget --output-document=mariadb-10.5.8-linux-systemd-x86_64.tar.gz https://downloads.mariadb.org/interstitial/mariadb-10.5.8/bintar-linux-systemd-x86_64/mariadb-10.5.8-linux-systemd-x86_64.tar.gz/from/https%3A//mirror.ufro.cl/mariadb/ 
sudo dbdeployer unpack mariadb-10.5.8-linux-systemd-x86_64.tar.gz 
sudo dbdeployer deploy single 8.0.22 \
--db-user=root
sudo dbdeployer deploy single 10.5.8 \
--db-user=root
sudo apt-get -y install wget ca-certificates 
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add - 
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main" >> /etc/apt/sources.list.d/pgdg.list' 
sudo apt-get update 
sudo apt-get -y install postgresql postgresql-contrib 
sudo updatedb
curl -s https://packagecloud.io/install/repositories/akopytov/sysbench/script.deb.sh | sudo bash 
sudo apt -y install sysbench
sudo apt-get update
sudo apt-get install \    apt-transport-https \    ca-certificates \    curl \    gnupg-agent \    software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt-key fingerprint 0EBFCD88 
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
sudo apt-get update
sudo apt-get -y install docker-ce docker-ce-cli containerd.io
sudo git clone https://github.com/Percona-Lab/sysbench-tpcc.git
echo "FINISHED!"
exit 0