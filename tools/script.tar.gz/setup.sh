sudo mkdir -p /mnt/extra/dbdeployer
cd /mnt/extra/dbdeployer
sudo wget https://github.com/datacharmer/dbdeployer/releases/download/v1.58.0/dbdeployer-1.58.0.linux.tar.gz 
sudo tar -xzf dbdeployer-1.58.0.linux.tar.gz 
sudo chmod +x dbdeployer-1.58.0.linux 
sudo mv dbdeployer-1.58.0.linux /usr/local/bin/dbdeployer 
sudo dbdeployer 
sudo mkdir -p /opt/dbdeployer
cd /opt/dbdeployer
sudo apt-get update 
sudo apt-get install libaio1 
sudo dbdeployer --sandbox-binary /opt/dbdeployer/opt/mysql --sandbox-home /opt/dbdeployer/sandboxes init  
sudo wget --output-document=mariadb-10.5.8-linux-systemd-x86_64.tar.gz https://downloads.mariadb.org/interstitial/mariadb-10.5.8/bintar-linux-systemd-x86_64/mariadb-10.5.8-linux-systemd-x86_64.tar.gz/from/https%3A//mirror.ufro.cl/mariadb/ 
sudo dbdeployer unpack mariadb-10.5.8-linux-systemd-x86_64.tar.gz 
sudo dbdeployer deploy single ./sandboxes 10.5.8 
sudo dbdeployer deploy single ./sandboxes 8.0.22 
echo "FINISHED!"
exit 0