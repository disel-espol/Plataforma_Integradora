#!/bin/bash
sudo mkdir -p /opt/setup
cd /opt/setup || exit 1
sudo wget https://github.com/datacharmer/dbdeployer/releases/download/v1.58.0/dbdeployer-1.58.0.linux.tar.gz 
sudo tar -xzf dbdeployer-1.58.0.linux.tar.gz 
sudo chmod +x dbdeployer-1.58.0.linux 
sudo mv dbdeployer-1.58.0.linux /usr/local/bin/dbdeployer 
sudo dbdeployer 
sudo apt-get update 
sudo apt-get install libaio1 
sudo dbdeployer init  
sudo wget --output-document=mariadb-10.5.8-linux-systemd-x86_64.tar.gz https://downloads.mariadb.org/interstitial/mariadb-10.5.8/bintar-linux-systemd-x86_64/mariadb-10.5.8-linux-systemd-x86_64.tar.gz/from/https%3A//mirror.ufro.cl/mariadb/ 
sudo dbdeployer unpack mariadb-10.5.8-linux-systemd-x86_64.tar.gz 
sudo dbdeployer deploy single 8.0.22
sudo dbdeployer deploy single 10.5.8 --my-cnf-options="performance_schema=ON"
sudo apt-get -y install wget ca-certificates 
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add - 
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main" >> /etc/apt/sources.list.d/pgdg.list' 
sudo apt-get update 
sudo apt-get -y install postgresql postgresql-contrib 
sudo updatedb
curl -s https://packagecloud.io/install/repositories/akopytov/sysbench/script.deb.sh | sudo bash 
sudo apt -y install sysbench
sudo apt-get update
sudo apt-get install \    apt-transport-https \    ca-certificates \    curl \    gnupg-agent \    software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt-key fingerprint 0EBFCD88 
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
sudo apt-get update
sudo apt-get -y install docker-ce docker-ce-cli containerd.io
cd ~
sudo git clone https://github.com/Percona-Lab/sysbench-tpcc.git
sudo  docker create -v /srv --name pmm-data percona/pmm-server:2 /bin/true
sudo  docker run -d -p 80:80 -p 443:443 --volumes-from pmm-data --name pmm-server --restart always percona/pmm-server:2
wget https://repo.percona.com/apt/percona-release_latest.bionic_all.deb
sudo dpkg -i percona-release_latest.bionic_all.deb 
sudo apt-get update
sudo apt-get install pmm2-client
sudo pmm-admin config --server-insecure-tls --server-url=https://admin:admin@localhost
sudo chmod 777 sysbench-tpcc
touch logs.txt
echo "FINISHED!"
exit 0